# Compute Statistics

Here we compute statistics for a bunch of measurements arriving from a sensor.

This project uses the Xunit framework to test functionality.
[See here](https://docs.microsoft.com/en-us/dotnet/core/testing/unit-testing-with-dotnet-test)
for details.

## Pass the tests

The code is not complete and doesn't even compile.
See the results of compilation and execution in the GitHub 'Actions' tab.

Recognize the intention of the code by reading the tests.
Design the return type in the code.
You may alter the test while keeping its intent.

Take care not to leave behind any compiler warnings in your solution.
